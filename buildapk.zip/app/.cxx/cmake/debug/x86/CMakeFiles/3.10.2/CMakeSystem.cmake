set(CMAKE_HOST_SYSTEM "Windows-10.0.19044")
set(CMAKE_HOST_SYSTEM_NAME "Windows")
set(CMAKE_HOST_SYSTEM_VERSION "10.0.19044")
set(CMAKE_HOST_SYSTEM_PROCESSOR "AMD64")

include("C:/Users/wangke/AppData/Local/Android/Sdk/ndk/android-ndk-r21e-windows-x86_64/android-ndk-r21e/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "i686")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
